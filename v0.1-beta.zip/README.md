# Solarized Fox

Simple theme to make Firefox as soothing on the eyes as it is pleasing!

This theme will theme Firefox in SOlarized Light from 6am to 6pm, and uses Solarized Dark for all other times. 

Only Firefox is themed by this extension; however, you can setup a custom style using [Stylus](https://addons.mozilla.org/en-US/firefox/addon/styl-us/?src=search), or [Global Dark](https://addons.mozilla.org/en-US/firefox/addon/dark-mode-webextension/?src=search) add-ons with a custom theme/CSS. I threw [this](https://userstyles.org/styles/158210/solarized-light-global) together in 10 minutes.

## Credits

* Significant inspiration from the [example dynamic extension](https://github.com/mdn/webextensions-examples/tree/master/dynamic-theme) — a wonderful start to my first browser theme/extension

* The amazing [Solarized theme](http://ethanschoonover.com/solarized) by Ethan Schoonover. The icon graphic is also from there!

TODO: follow instructions for porting the theme